# ProjectAPI - Code Project Management System

This Django app provides a comprehensive system for managing code projects, including creation, editing, collaboration, execution, and monetization features.

## Features

### 1. Project Management
- **Create, Edit, Update, Delete** projects
- Support for different project types: Code, Text, and Mixed Content
- Public and private project visibility
- Project approval workflow

### 2. Code Execution & Testing
- **Run code projects** to test functionality
- Resource usage tracking and cost calculation
- Execution history and usage statistics

### 3. Pricing & Monetization
- Set project prices (one-time purchase)
- Set per-use pricing (pay-per-execution)
- Automatic cost calculation based on computing resources
- Integration with user balance system

### 4. Computing Resource Analysis
- **Automatic analysis** of code complexity
- CPU and memory usage estimation
- Execution time prediction
- Cost calculation based on server costs ($20/month)

### 5. Search & Discovery
- **Search functionality** for public projects
- Filter by project type, price range
- Public project browsing

### 6. Collaboration System
- **Multi-user collaboration** on projects
- Role-based permissions (Viewer, Editor, Admin)
- Public/private collaborator visibility
- Approval workflow for changes

### 7. Version Control
- **Public and private versions** for each project
- Version approval system
- Separate content for code and text projects

### 8. Admin Management
- **Admin panel** for project review and approval
- Bulk project management
- User access control

## Models

### Project
- Basic project information (title, description, owner)
- Visibility settings (public/private)
- Pricing configuration
- Approval status

### ProjectVersion
- Version control for project content
- Separate public and private versions
- Approval workflow
- Code and text content support

### ProjectCollaborator
- User collaboration management
- Role-based permissions
- Public/private visibility settings

### ProjectUsage
- Track user usage of projects
- Cost tracking per user
- Usage statistics

### ComputingResource
- Resource usage estimation
- Cost calculation algorithms
- Performance metrics

## API Endpoints

### Projects
- `GET /api/projects/` - List user's projects
- `POST /api/projects/` - Create new project
- `GET /api/projects/{id}/` - Get project details
- `PUT /api/projects/{id}/` - Update project
- `DELETE /api/projects/{id}/` - Delete project

### Project Actions
- `GET /api/projects/my_projects/` - List owned projects
- `GET /api/projects/search/` - Search public projects
- `POST /api/projects/{id}/run/` - Execute project
- `POST /api/projects/{id}/buy/` - Purchase project access
- `POST /api/projects/{id}/add_collaborator/` - Add collaborator
- `DELETE /api/projects/{id}/remove_collaborator/` - Remove collaborator

### Versions
- `GET /api/projects/{project_id}/versions/` - List versions
- `POST /api/projects/{project_id}/versions/` - Create version
- `POST /api/projects/{project_id}/versions/{id}/approve/` - Approve version

### Computing Resources
- `GET /api/projects/{project_id}/computing-resources/` - Get resources
- `POST /api/projects/{project_id}/computing-resources/{id}/analyze_code/` - Analyze code

### Admin
- `GET /api/admin/projects/` - List all projects (admin)
- `POST /api/admin/projects/{id}/approve/` - Approve project (admin)
- `POST /api/admin/projects/{id}/reject/` - Reject project (admin)
- `GET /api/admin/projects/pending_review/` - Pending projects (admin)

## Usage Examples

### Creating a Project
```python
# Create a new code project
project_data = {
    'title': 'My Python Script',
    'description': 'A useful Python script for data processing',
    'is_public': True,
    'project_type': 'code',
    'price': '10.00',
    'price_per_use': '0.10'
}
response = requests.post('/api/projects/', json=project_data)
```

### Running a Project
```python
# Execute a project
run_data = {
    'project_id': 'project-uuid',
    'input_data': {'param1': 'value1'},
    'parameters': {'timeout': 30}
}
response = requests.post('/api/projects/project-uuid/run/', json=run_data)
```

### Searching Projects
```python
# Search for public projects
response = requests.get('/api/projects/search/?q=python&type=code&min_price=5&max_price=20')
```

### Buying a Project
```python
# Purchase access to a project
buy_data = {
    'project_id': 'project-uuid',
    'payment_method': 'balance'
}
response = requests.post('/api/projects/project-uuid/buy/', json=buy_data)
```

## Cost Calculation

The system calculates costs based on:
- **Monthly server cost**: $20/month
- **Resource usage**: CPU percentage + Memory usage
- **Execution time**: Time in seconds
- **Formula**: `(CPU% + Memory%) * execution_time * monthly_cost / (30 * 24 * 3600)`

## Installation

1. Add `projectApi` to `INSTALLED_APPS` in settings.py
2. Run migrations: `python manage.py migrate`
3. Add URL patterns to main urls.py
4. Test with: `python manage.py test_project_api`

## Testing

Run the test command to create sample data:
```bash
python manage.py test_project_api
```

This will create:
- A test user with balance
- A sample code project
- A public version with approved code
- Computing resources with cost calculation 