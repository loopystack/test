from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase
from rest_framework import status
from decimal import Decimal

from .models import Project, ProjectVersion, ProjectCollaborator, ProjectUsage, ComputingResource

User = get_user_model()

class ProjectModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email='test@example.com',
            password='testpass123'
        )
    
    def test_project_creation(self):
        project = Project.objects.create(
            title='Test Project',
            description='A test project',
            owner=self.user,
            price=Decimal('10.00'),
            price_per_use=Decimal('0.10')
        )
        
        self.assertEqual(project.title, 'Test Project')
        self.assertEqual(project.owner, self.user)
        self.assertEqual(project.price, Decimal('10.00'))
        self.assertFalse(project.is_public)
        self.assertFalse(project.is_approved)
    
    def test_project_urls_generation(self):
        project = Project.objects.create(
            title='Test Project',
            description='A test project',
            owner=self.user
        )
        
        self.assertIsNotNone(project.public_url)
        self.assertIsNotNone(project.private_url)
        self.assertIn(str(project.id), project.public_url)
        self.assertIn(str(project.id), project.private_url)

class ProjectAPITest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email='test@example.com',
            password='testpass123'
        )
        self.client.force_authenticate(user=self.user)
        
        self.project = Project.objects.create(
            title='Test Project',
            description='A test project',
            owner=self.user,
            price=Decimal('10.00'),
            price_per_use=Decimal('0.10')
        )
    
    def test_create_project(self):
        data = {
            'title': 'New Project',
            'description': 'A new test project',
            'is_public': True,
            'project_type': 'code',
            'price': '15.00',
            'price_per_use': '0.15'
        }
        
        response = self.client.post('/api/projects/', data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Project.objects.count(), 2)
        
        project = Project.objects.get(title='New Project')
        self.assertEqual(project.owner, self.user)
        self.assertTrue(project.is_public)
        
        # Check that owner information is included in the response
        self.assertIn('owner', response.data)
        self.assertEqual(response.data['owner']['id'], self.user.id)
        self.assertEqual(response.data['owner']['email'], self.user.email)
    
    def test_update_project(self):
        data = {
            'title': 'Updated Project',
            'description': 'An updated test project',
            'is_public': True,
            'project_type': 'text',
            'price': '20.00',
            'price_per_use': '0.20'
        }
        
        response = self.client.patch(f'/api/projects/{self.project.id}/', data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        # Check that owner information is included in the response
        self.assertIn('owner', response.data)
        self.assertEqual(response.data['owner']['id'], self.user.id)
        self.assertEqual(response.data['owner']['email'], self.user.email)
        
        # Check that the project was updated
        self.project.refresh_from_db()
        self.assertEqual(self.project.title, 'Updated Project')
        self.assertEqual(self.project.project_type, 'text')
    
    def test_list_my_projects(self):
        response = self.client.get('/api/projects/my_projects/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['title'], 'Test Project')
    
    def test_search_projects(self):
        # Make project public and approved
        self.project.is_public = True
        self.project.is_approved = True
        self.project.save()
        
        response = self.client.get('/api/projects/search/?q=test')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['title'], 'Test Project')
    
    def test_run_project(self):
        # Create an approved version
        version = ProjectVersion.objects.create(
            project=self.project,
            version_number=1,
            version_type='public',
            content='print("Hello World")',
            code_content='print("Hello World")',
            is_approved=True,
            created_by=self.user
        )
        
        data = {
            'project_id': str(self.project.id),
            'input_data': {'test': 'data'}
        }
        
        response = self.client.post(f'/api/projects/{self.project.id}/run/', data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        # Check that usage was recorded
        usage = ProjectUsage.objects.get(project=self.project, user=self.user)
        self.assertEqual(usage.usage_count, 1)
    
    def test_buy_project(self):
        # Set user balance
        self.user.balance = Decimal('20.00')
        self.user.save()
        
        # Make project public
        self.project.is_public = True
        self.project.save()
        
        data = {
            'project_id': str(self.project.id),
            'payment_method': 'balance'
        }
        
        response = self.client.post(f'/api/projects/{self.project.id}/buy/', data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        # Check that user was added as collaborator
        collaborator = ProjectCollaborator.objects.get(project=self.project, user=self.user)
        self.assertEqual(collaborator.role, 'editor')
        
        # Check that balance was deducted
        self.user.refresh_from_db()
        self.assertEqual(self.user.balance, Decimal('10.00'))

class ProjectVersionTest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email='test@example.com',
            password='testpass123'
        )
        self.client.force_authenticate(user=self.user)
        
        self.project = Project.objects.create(
            title='Test Project',
            description='A test project',
            owner=self.user
        )
    
    def test_create_version(self):
        data = {
            'version_number': 1,
            'version_type': 'public',
            'content': 'Test content',
            'code_content': 'print("Hello World")',
            'text_content': 'This is a test project'
        }
        
        response = self.client.post(f'/api/projects/{self.project.id}/versions/', data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        
        version = ProjectVersion.objects.get(project=self.project)
        self.assertEqual(version.version_number, 1)
        self.assertEqual(version.created_by, self.user)
        
        # Check that creator information is included in the response
        self.assertIn('created_by', response.data)
        self.assertEqual(response.data['created_by']['id'], self.user.id)
        self.assertEqual(response.data['created_by']['email'], self.user.email)
    
    def test_approve_version(self):
        version = ProjectVersion.objects.create(
            project=self.project,
            version_number=1,
            version_type='public',
            content='Test content',
            created_by=self.user
        )
        
        response = self.client.post(f'/api/projects/{self.project.id}/versions/{version.id}/approve/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        version.refresh_from_db()
        self.assertTrue(version.is_approved)
        self.assertEqual(version.approved_by, self.user)

class ComputingResourceTest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email='test@example.com',
            password='testpass123'
        )
        self.client.force_authenticate(user=self.user)
        
        self.project = Project.objects.create(
            title='Test Project',
            description='A test project',
            owner=self.user
        )
        
        self.version = ProjectVersion.objects.create(
            project=self.project,
            version_number=1,
            version_type='public',
            content='Test content',
            code_content='import os\nprint("Hello World")',
            created_by=self.user
        )
        
        self.resource = ComputingResource.objects.create(
            project=self.project
        )
    
    def test_analyze_code(self):
        response = self.client.post(f'/api/projects/{self.project.id}/computing-resources/{self.resource.id}/analyze_code/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        self.resource.refresh_from_db()
        self.assertGreater(self.resource.cpu_usage, 0)
        self.assertGreater(self.resource.memory_usage, 0)
        self.assertGreater(self.resource.execution_time, 0)
        self.assertGreater(self.resource.estimated_cost_per_run, 0) 