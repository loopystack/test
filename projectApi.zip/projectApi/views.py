from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404
from django.db.models import Q, Count, Sum
from django.utils import timezone
from decimal import Decimal
import requests
import json

from .models import Project, ProjectVersion, ProjectCollaborator, ProjectUsage, ComputingResource, ProjectPurchase, ProjectView
from .serializers import (
    ProjectSerializer, ProjectCreateSerializer, ProjectUpdateSerializer,
    ProjectVersionSerializer, ProjectVersionCreateSerializer,
    ProjectCollaboratorSerializer, ProjectUsageSerializer,
    ComputingResourceSerializer, ProjectSearchSerializer,
    ProjectRunSerializer, ProjectBuySerializer, ProjectAnalyticsSerializer,
    ProjectPurchaseSerializer, ProjectViewSerializer
)
from django.contrib.auth import get_user_model
User = get_user_model()

class IsOwnerOrReadOnly(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return obj.owner == request.user

class IsCollaboratorOrReadOnly(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        if obj.owner == request.user:
            return True
        collaborator = obj.projectcollaborator_set.filter(user=request.user).first()
        return collaborator is not None and collaborator.role in ['editor', 'admin']

class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    permission_classes = [permissions.IsAuthenticated, IsOwnerOrReadOnly]
    
    def get_serializer_class(self):
        if self.action == 'create':
            return ProjectCreateSerializer
        elif self.action in ['update', 'partial_update']:
            return ProjectUpdateSerializer
        return ProjectSerializer
    
    def get_queryset(self):
        # Allow any authenticated user to access any project
        # The authentication requirement is handled by permission_classes
        return Project.objects.all()
    
    @action(detail=False, methods=['get'])
    def my_projects(self, request):
        """Get projects owned by the current user"""
        projects = Project.objects.filter(owner=request.user)
        serializer = self.get_serializer(projects, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def search(self, request):
        """Enhanced search for public projects"""
        query = request.query_params.get('q', '')
        project_type = request.query_params.get('type', '')
        min_price = request.query_params.get('min_price', '')
        max_price = request.query_params.get('max_price', '')
        language = request.query_params.get('language', '')
        sort_by = request.query_params.get('sort_by', 'created_at')
        sort_order = request.query_params.get('sort_order', 'desc')
        
        queryset = Project.objects.filter(is_public=True, is_approved=True)
        
        if query:
            queryset = queryset.filter(
                Q(title__icontains=query) | 
                Q(description__icontains=query) |
                Q(owner__first_name__icontains=query) |
                Q(owner__last_name__icontains=query)
            )
        
        if project_type:
            queryset = queryset.filter(project_type=project_type)
        
        if language:
            queryset = queryset.filter(language=language)
        
        if min_price:
            queryset = queryset.filter(price__gte=Decimal(min_price))
        
        if max_price:
            queryset = queryset.filter(price__lte=Decimal(max_price))
        
        # Sorting
        if sort_by == 'price':
            queryset = queryset.order_by(f'{"-" if sort_order == "desc" else ""}price')
        elif sort_by == 'views':
            queryset = queryset.order_by(f'{"-" if sort_order == "desc" else ""}total_views')
        elif sort_by == 'runs':
            queryset = queryset.order_by(f'{"-" if sort_order == "desc" else ""}total_runs')
        elif sort_by == 'revenue':
            queryset = queryset.order_by(f'{"-" if sort_order == "desc" else ""}total_revenue')
        else:
            queryset = queryset.order_by(f'{"-" if sort_order == "desc" else ""}created_at')
        
        serializer = ProjectSearchSerializer(queryset, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['post'])
    def run(self, request, pk=None):
        """Run a project's code"""
        project = self.get_object()
        serializer = ProjectRunSerializer(data=request.data)
        
        if serializer.is_valid():
            if not (project.owner == request.user or 
                   project.projectcollaborator_set.filter(user=request.user).exists()):
                return Response(
                    {"error": "You don't have permission to run this project"},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            latest_version = project.versions.filter(
                version_type='public', is_approved=True
            ).first()
            
            if not latest_version:
                return Response(
                    {"error": "No approved version found"},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Track usage
            usage, created = ProjectUsage.objects.get_or_create(
                project=project, user=request.user
            )
            usage.increment_usage()
            project.increment_run()
            
            computing_resource = project.computing_resources.first()
            if not computing_resource:
                computing_resource = ComputingResource.objects.create(project=project)
            
            return Response({
                "message": "Project executed successfully",
                "usage_count": usage.usage_count,
                "cost_per_run": computing_resource.estimated_cost_per_run,
                "total_cost": usage.total_cost,
                "project_analytics": {
                    "total_runs": project.total_runs,
                    "total_revenue": str(project.total_revenue)
                }
            })
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def buy(self, request, pk=None):
        """Buy access to a project"""
        project = self.get_object()
        serializer = ProjectBuySerializer(data=request.data)
        
        if serializer.is_valid():
            if project.owner == request.user:
                return Response(
                    {"error": "You already own this project"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            purchase_type = serializer.validated_data.get('purchase_type', 'one_time')
            
            if purchase_type == 'one_time':
                amount = project.price
            else:
                amount = project.price_per_use
            
            if request.user.balance < amount:
                return Response(
                    {"error": "Insufficient balance"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Deduct balance
            request.user.balance -= amount
            request.user.save()
            
            # Create purchase record
            ProjectPurchase.objects.create(
                project=project,
                buyer=request.user,
                amount_paid=amount,
                purchase_type=purchase_type
            )
            
            # Update project analytics
            project.increment_purchase(amount)
            
            # Add as collaborator if one-time purchase
            if purchase_type == 'one_time':
                ProjectCollaborator.objects.get_or_create(
                    project=project,
                    user=request.user,
                    defaults={
                        'role': 'editor'
                    }
                )
            
            return Response({
                "message": "Project purchased successfully",
                "remaining_balance": request.user.balance,
                "amount_paid": amount,
                "purchase_type": purchase_type
            })
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['get'])
    def collaborators(self, request, pk=None):
        """Get project collaborators"""
        project = self.get_object()
        collaborators = project.projectcollaborator_set.all()
        serializer = ProjectCollaboratorSerializer(collaborators, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['post'])
    def add_collaborator(self, request, pk=None):
        """Add a collaborator to the project"""
        project = self.get_object()
        
        if project.owner != request.user:
            return Response(
                {"error": "Only project owner can add collaborators"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        serializer = ProjectCollaboratorSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(project=project)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['delete'])
    def remove_collaborator(self, request, pk=None):
        """Remove a collaborator from the project"""
        project = self.get_object()
        user_id = request.data.get('user_id')
        
        if project.owner != request.user:
            return Response(
                {"error": "Only project owner can remove collaborators"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        collaborator = get_object_or_404(ProjectCollaborator, project=project, user_id=user_id)
        collaborator.delete()
        
        return Response({"message": "Collaborator removed successfully"})
    
    @action(detail=True, methods=['post'])
    def submit_version_for_review(self, request, pk=None):
        """Submit a new version for review (for collaborators)"""
        project = self.get_object()
        
        # Check if user is collaborator with editor or admin role
        collaborator = project.projectcollaborator_set.filter(
            user=request.user, 
            role__in=['editor', 'admin']
        ).first()
        
        if not collaborator and project.owner != request.user:
            return Response(
                {"error": "You don't have permission to submit versions"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Create a new private version for review
        latest_version = project.versions.filter(version_type='private').order_by('-version_number').first()
        new_version_number = (latest_version.version_number if latest_version else 0) + 1
        
        version_data = {
            'version_number': new_version_number,
            'version_type': 'private',
            'content': request.data.get('content', ''),
            'code_content': request.data.get('code_content', ''),
            'text_content': request.data.get('text_content', ''),
            'usage_instructions': request.data.get('usage_instructions', ''),
            'examples': request.data.get('examples', []),
            'created_by': request.user.id,
            'is_approved': False
        }
        
        serializer = ProjectVersionCreateSerializer(data=version_data)
        if serializer.is_valid():
            serializer.save(project=project)
            return Response({
                "message": "Version submitted for review successfully",
                "version": serializer.data
            }, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['get'])
    def pending_versions(self, request, pk=None):
        """Get pending versions for review (for project owners/admins)"""
        project = self.get_object()
        
        if project.owner != request.user:
            return Response(
                {"error": "Only project owner can view pending versions"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        pending_versions = project.versions.filter(
            version_type='private',
            is_approved=False
        ).order_by('-created_at')
        
        serializer = ProjectVersionSerializer(pending_versions, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def analytics(self, request, pk=None):
        """Get project analytics"""
        project = self.get_object()
        
        if not (project.owner == request.user or 
               project.projectcollaborator_set.filter(user=request.user, role__in=['editor', 'admin']).exists()):
            return Response(
                {"error": "You don't have permission to view analytics"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        serializer = ProjectAnalyticsSerializer(project)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def user_usage(self, request, pk=None):
        """Get current user's usage statistics for this project"""
        project = self.get_object()
        
        usage, created = ProjectUsage.objects.get_or_create(
            project=project, 
            user=request.user,
            defaults={'usage_count': 0, 'total_cost': 0.00}
        )
        
        serializer = ProjectUsageSerializer(usage)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def usage(self, request, pk=None):
        """Get all usage statistics for this project (admin/owner only)"""
        project = self.get_object()
        
        if not (project.owner == request.user or 
               project.projectcollaborator_set.filter(user=request.user, role__in=['editor', 'admin']).exists()):
            return Response(
                {"error": "You don't have permission to view usage statistics"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        usage_records = project.usage_records.all()
        serializer = ProjectUsageSerializer(usage_records, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['post'])
    def view(self, request, pk=None):
        """Track project view"""
        project = self.get_object()
        
        # Create view record
        ProjectView.objects.create(
            project=project,
            viewer=request.user if request.user.is_authenticated else None,
            ip_address=request.META.get('REMOTE_ADDR', ''),
            user_agent=request.META.get('HTTP_USER_AGENT', '')
        )
        
        # Increment view count
        project.increment_view()
        
        return Response({"message": "View tracked successfully"})

    @action(detail=True, methods=['post'])
    def submit_for_review(self, request, pk=None):
        """Submit project for review"""
        project = self.get_object()
        
        if project.owner != request.user:
            return Response(
                {"error": "Only project owner can submit for review"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        if project.status not in ['draft', 'rejected']:
            return Response(
                {"error": "Project can only be submitted for review from draft or rejected status"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Update project status to pending
        project.status = 'pending'
        project.save()
        
        return Response({
            "message": "Project submitted for review successfully",
            "status": "pending"
        })

class ProjectVersionViewSet(viewsets.ModelViewSet):
    queryset = ProjectVersion.objects.all()
    serializer_class = ProjectVersionSerializer
    permission_classes = [permissions.IsAuthenticated, IsCollaboratorOrReadOnly]
    
    def get_queryset(self):
        user = self.request.user
        project_pk = self.kwargs.get('project_pk')
        
        if project_pk:
            project = get_object_or_404(Project, pk=project_pk)
            # Show all versions to owner and approved collaborators
            if project.owner == user or project.projectcollaborator_set.filter(
                user=user, role__in=['editor', 'admin']
            ).exists():
                return project.versions.all()
            # Show only public approved versions to others
            return project.versions.filter(version_type='public', is_approved=True)
        
        return ProjectVersion.objects.none()
    
    def get_serializer_class(self):
        if self.action == 'create':
            return ProjectVersionCreateSerializer
        return ProjectVersionSerializer
    
    def perform_create(self, serializer):
        project_pk = self.kwargs.get('project_pk')
        project = get_object_or_404(Project, pk=project_pk)
        serializer.save(project=project, created_by=self.request.user)
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None, project_pk=None):
        """Approve a version and make it public"""
        version = self.get_object()
        project = version.project
        
        # Check permissions
        if project.owner != request.user and not project.projectcollaborator_set.filter(
            user=request.user, role__in=['editor', 'admin']
        ).exists():
            return Response(
                {"error": "You don't have permission to approve versions"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Approve the version
        version.approve(request.user)
        
        # If this is a private version being approved, create a public version
        if version.version_type == 'private':
            # Create a new public version with the same content
            latest_public = project.versions.filter(version_type='public').order_by('-version_number').first()
            new_public_version_number = (latest_public.version_number if latest_public else 0) + 1
            
            public_version = ProjectVersion.objects.create(
                project=project,
                version_number=new_public_version_number,
                version_type='public',
                content=version.content,
                code_content=version.code_content,
                text_content=version.text_content,
                usage_instructions=version.usage_instructions,
                examples=version.examples,
                created_by=version.created_by,
                is_approved=True,
                approved_by=request.user,
                approved_at=timezone.now()
            )
            
            return Response({
                "message": "Version approved and published successfully",
                "public_version": ProjectVersionSerializer(public_version).data
            })
        
        return Response({
            "message": "Version approved successfully"
        })
    
    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None, project_pk=None):
        """Reject a version with reason"""
        version = self.get_object()
        project = version.project
        reason = request.data.get('reason', '')
        
        # Check permissions
        if project.owner != request.user and not project.projectcollaborator_set.filter(
            user=request.user, role__in=['editor', 'admin']
        ).exists():
            return Response(
                {"error": "You don't have permission to reject versions"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Reject the version
        version.reject(request.user, reason)
        
        return Response({
            "message": "Version rejected successfully",
            "reason": reason
        })
    
    @action(detail=True, methods=['post'])
    def promote_to_public(self, request, pk=None, project_pk=None):
        """Promote a private version to public (for project owners)"""
        version = self.get_object()
        project = version.project
        
        # Only project owner can promote versions
        if project.owner != request.user:
            return Response(
                {"error": "Only project owner can promote versions to public"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        if version.version_type != 'private':
            return Response(
                {"error": "Only private versions can be promoted to public"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Create a new public version
        latest_public = project.versions.filter(version_type='public').order_by('-version_number').first()
        new_public_version_number = (latest_public.version_number if latest_public else 0) + 1
        
        public_version = ProjectVersion.objects.create(
            project=project,
            version_number=new_public_version_number,
            version_type='public',
            content=version.content,
            code_content=version.code_content,
            text_content=version.text_content,
            usage_instructions=version.usage_instructions,
            examples=version.examples,
            created_by=version.created_by,
            is_approved=True,
            approved_by=request.user,
            approved_at=timezone.now()
        )
        
        return Response({
            "message": "Version promoted to public successfully",
            "public_version": ProjectVersionSerializer(public_version).data
        })

class AdminProjectViewSet(viewsets.ModelViewSet):
    """Admin viewset for managing all projects"""
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer
    permission_classes = [permissions.IsAdminUser]
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Approve a project"""
        project = self.get_object()
        project.status = 'approved'
        project.is_approved = True
        project.save()
        
        # Approve the latest public version if it exists
        latest_version = project.versions.filter(version_type='public').first()
        if latest_version:
            latest_version.approve(request.user)
        
        return Response({
            "message": "Project approved successfully",
            "status": "approved"
        })
    
    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        """Reject a project with reason"""
        project = self.get_object()
        reason = request.data.get('reason', '')
        
        project.status = 'rejected'
        project.is_approved = False
        project.save()
        
        # Reject the latest public version if it exists
        latest_version = project.versions.filter(version_type='public').first()
        if latest_version:
            latest_version.reject(request.user, reason)
        
        return Response({
            "message": "Project rejected successfully",
            "status": "rejected",
            "reason": reason
        })
    
    @action(detail=False, methods=['get'])
    def pending_review(self, request):
        """Get projects pending review"""
        projects = Project.objects.filter(status='pending')
        serializer = self.get_serializer(projects, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def analytics(self, request):
        """Get admin analytics"""
        total_projects = Project.objects.count()
        approved_projects = Project.objects.filter(status='approved').count()
        pending_projects = Project.objects.filter(status='pending').count()
        rejected_projects = Project.objects.filter(status='rejected').count()
        
        # Calculate total revenue
        total_revenue = Project.objects.aggregate(
            total=Sum('total_revenue')
        )['total'] or 0
        
        # Get top performing projects
        top_projects = Project.objects.filter(is_approved=True).order_by('-total_revenue')[:10]
        
        return Response({
            'total_projects': total_projects,
            'approved_projects': approved_projects,
            'pending_projects': pending_projects,
            'rejected_projects': rejected_projects,
            'total_revenue': total_revenue,
            'top_projects': ProjectSearchSerializer(top_projects, many=True).data
        })

    @action(detail=True, methods=['post'])
    def run_project(self, request, pk=None):
        """Run a project's code (admin version)"""
        project = self.get_object()
        serializer = ProjectRunSerializer(data=request.data)
        
        if serializer.is_valid():
            latest_version = project.versions.filter(
                version_type='public', is_approved=True
            ).first()
            
            if not latest_version:
                return Response(
                    {"error": "No approved version found"},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Track usage
            usage, created = ProjectUsage.objects.get_or_create(
                project=project, user=request.user
            )
            usage.increment_usage()
            project.increment_run()
            
            computing_resource = project.computing_resources.first()
            if not computing_resource:
                computing_resource = ComputingResource.objects.create(project=project)
            
            return Response({
                "message": "Project executed successfully",
                "usage_count": usage.usage_count,
                "cost_per_run": computing_resource.estimated_cost_per_run,
                "total_cost": usage.total_cost,
                "project_analytics": {
                    "total_runs": project.total_runs,
                    "total_revenue": str(project.total_revenue)
                }
            })
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def buy_project(self, request, pk=None):
        """Buy access to a project (admin version)"""
        project = self.get_object()
        serializer = ProjectBuySerializer(data=request.data)
        
        if serializer.is_valid():
            purchase_type = serializer.validated_data.get('purchase_type', 'one_time')
            
            if purchase_type == 'one_time':
                amount = project.price
            else:
                amount = project.price_per_use
            
            if request.user.balance < amount:
                return Response(
                    {"error": "Insufficient balance"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Deduct balance
            request.user.balance -= amount
            request.user.save()
            
            # Create purchase record
            ProjectPurchase.objects.create(
                project=project,
                buyer=request.user,
                amount_paid=amount,
                purchase_type=purchase_type
            )
            
            # Update project analytics
            project.increment_purchase(amount)
            
            # Add as collaborator if one-time purchase
            if purchase_type == 'one_time':
                ProjectCollaborator.objects.get_or_create(
                    project=project,
                    user=request.user,
                    defaults={
                        'role': 'editor'
                    }
                )
            
            return Response({
                "message": "Project purchased successfully",
                "amount_paid": amount,
                "purchase_type": purchase_type,
                "project_analytics": {
                    "total_purchases": project.total_purchases,
                    "total_revenue": str(project.total_revenue)
                }
            })
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def track_view(self, request, pk=None):
        """Track project view (admin version)"""
        project = self.get_object()
        
        # Get client IP and user agent
        ip_address = self.get_client_ip(request)
        user_agent = request.META.get('HTTP_USER_AGENT', '')
        
        # Create view record
        ProjectView.objects.create(
            project=project,
            viewer=request.user if request.user.is_authenticated else None,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        # Update project analytics
        project.increment_view()
        
        return Response({"message": "View tracked successfully"})
    
    @action(detail=True, methods=['get'])
    def user_usage(self, request, pk=None):
        """Get current user's usage statistics for this project (admin version)"""
        project = self.get_object()
        
        usage, created = ProjectUsage.objects.get_or_create(
            project=project, 
            user=request.user,
            defaults={'usage_count': 0, 'total_cost': 0.00}
        )
        
        serializer = ProjectUsageSerializer(usage)
        return Response(serializer.data)
    
    def get_client_ip(self, request):
        """Get client IP address"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip

    @action(detail=True, methods=['post'])
    def add_collaborator_admin(self, request, pk=None):
        """Add collaborator to project (admin version)"""
        project = self.get_object()
        email = request.data.get('email')
        role = request.data.get('role', 'editor')
        
        if not email:
            return Response(
                {"error": "Email is required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        if role not in ['editor', 'admin']:
            return Response(
                {"error": "Role must be 'editor' or 'admin'"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"error": "User not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        if project.owner == user:
            return Response(
                {"error": "Cannot add owner as collaborator"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        collaborator, created = ProjectCollaborator.objects.get_or_create(
            project=project,
            user=user,
            defaults={
                'role': role
            }
        )
        
        if not created:
            collaborator.role = role
            collaborator.save()
        
        return Response({
            "message": "Collaborator added successfully",
            "collaborator": {
                "id": user.id,
                "email": user.email,
                "role": collaborator.role
            }
        })

    @action(detail=True, methods=['delete'])
    def remove_collaborator_admin(self, request, pk=None):
        """Remove collaborator from project (admin version)"""
        project = self.get_object()
        user_id = request.data.get('user_id')
        
        if not user_id:
            return Response(
                {"error": "User ID is required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            collaborator = ProjectCollaborator.objects.get(
                project=project,
                user_id=user_id
            )
            collaborator.delete()
            return Response({"message": "Collaborator removed successfully"})
        except ProjectCollaborator.DoesNotExist:
            return Response(
                {"error": "Collaborator not found"},
                status=status.HTTP_404_NOT_FOUND
            )

    @action(detail=True, methods=['post'])
    def approve_version(self, request, pk=None):
        """Approve a project version (admin version)"""
        project = self.get_object()
        version_id = request.data.get('version_id')
        
        if not version_id:
            return Response(
                {"error": "Version ID is required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            version = ProjectVersion.objects.get(
                id=version_id,
                project=project
            )
            version.approve(request.user)
            return Response({"message": "Version approved successfully"})
        except ProjectVersion.DoesNotExist:
            return Response(
                {"error": "Version not found"},
                status=status.HTTP_404_NOT_FOUND
            )

    @action(detail=True, methods=['post'])
    def reject_version(self, request, pk=None):
        """Reject a project version (admin version)"""
        project = self.get_object()
        version_id = request.data.get('version_id')
        reason = request.data.get('reason', '')
        
        if not version_id:
            return Response(
                {"error": "Version ID is required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            version = ProjectVersion.objects.get(
                id=version_id,
                project=project
            )
            version.reject(request.user, reason)
            return Response({
                "message": "Version rejected successfully",
                "reason": reason
            })
        except ProjectVersion.DoesNotExist:
            return Response(
                {"error": "Version not found"},
                status=status.HTTP_404_NOT_FOUND
            )

class ComputingResourceViewSet(viewsets.ModelViewSet):
    queryset = ComputingResource.objects.all()
    serializer_class = ComputingResourceSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        project_id = self.kwargs.get('project_pk')
        return ComputingResource.objects.filter(project_id=project_id)
    
    @action(detail=True, methods=['post'])
    def analyze_code(self, request, pk=None, project_pk=None):
        """Analyze code and estimate resource usage"""
        resource = self.get_object()
        project = resource.project
        
        latest_version = project.versions.filter(version_type='public').first()
        if not latest_version:
            return Response(
                {"error": "No version found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Analyze code complexity
        resource.analyze_complexity(latest_version.content)
        
        return Response({
            "estimated_cpu_usage": resource.cpu_usage,
            "estimated_memory_usage": resource.memory_usage,
            "estimated_execution_time": resource.execution_time,
            "estimated_storage_usage": resource.storage_usage,
            "estimated_cost_per_run": resource.estimated_cost_per_run,
            "complexity_score": resource.complexity_score,
            "resource_intensity": resource.resource_intensity
        })

class PublicProjectView(APIView):
    """Public view for projects (no authentication required)"""
    permission_classes = [permissions.AllowAny]
    
    def get(self, request, public_url):
        """Get public project by URL (public_url parameter is now the project ID)"""
        try:
            # Try to find project by ID (the public_url parameter is now the project ID)
            project = Project.objects.get(id=public_url, is_public=True, is_approved=True)
            # Track view
            ProjectView.objects.create(
                project=project,
                viewer=request.user if request.user.is_authenticated else None,
                ip_address=request.META.get('REMOTE_ADDR', ''),
                user_agent=request.META.get('HTTP_USER_AGENT', '')
            )
            project.increment_view()
            
            serializer = ProjectSearchSerializer(project)
            return Response(serializer.data)
        except Project.DoesNotExist:
            return Response(
                {"error": "Project not found or not public"},
                status=status.HTTP_404_NOT_FOUND
            )

class CodeExecutionView(APIView):
    """Handle code execution through JDoodle API"""
    permission_classes = [permissions.IsAuthenticated]
    
    # Language mapping for JDoodle API
    LANGUAGE_MAP = {
        'javascript': {'jdoodle': 'nodejs', 'versionIndex': '3'},
        'python': {'jdoodle': 'python3', 'versionIndex': '3'},
        'java': {'jdoodle': 'java', 'versionIndex': '3'},
        'php': {'jdoodle': 'php', 'versionIndex': '3'},
        'go': {'jdoodle': 'go', 'versionIndex': '3'},
        'rust': {'jdoodle': 'rust', 'versionIndex': '2'},
        'sql': {'jdoodle': 'sql', 'versionIndex': '0'}
    }
    
    def post(self, request):
        """Execute code using JDoodle API"""
        try:
            code = request.data.get('code')
            language = request.data.get('language')
            
            if not code or not language:
                return Response(
                    {"error": "Code and language are required"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            if language not in self.LANGUAGE_MAP:
                return Response(
                    {"error": f"Unsupported language: {language}"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # JDoodle API credentials (should be moved to environment variables)
            client_id = '17d082eb40732dc01eb6de1f680827a'
            client_secret = '7ea4918d1d5ac4fd9296822841ae153d3f4c709f7383f6c913a53fa6198116c4'
            
            # Prepare request to JDoodle API
            jdoodle_data = {
                'clientId': client_id,
                'clientSecret': client_secret,
                'script': code,
                'language': self.LANGUAGE_MAP[language]['jdoodle'],
                'versionIndex': self.LANGUAGE_MAP[language]['versionIndex']
            }
            
            # Make request to JDoodle API
            response = requests.post(
                'https://api.jdoodle.com/v1/execute',
                json=jdoodle_data,
                headers={'Content-Type': 'application/json'},
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                print(result)
                return Response({
                    'success': True,
                    'output': result.get('output', ''),
                    'error': result.get('error', ''),
                    'statusCode': result.get('statusCode', ''),
                    'memory': result.get('memory', ''),
                    'cpuTime': result.get('cpuTime', '')
                })
            else:
                return Response(
                    {"error": f"JDoodle API error: {response.status_code}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
                
        except requests.exceptions.Timeout:
            return Response(
                {"error": "Code execution timed out"},
                status=status.HTTP_408_REQUEST_TIMEOUT
            )
        except requests.exceptions.RequestException as e:
            return Response(
                {"error": f"Network error: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        except Exception as e:
            return Response(
                {"error": f"Unexpected error: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )