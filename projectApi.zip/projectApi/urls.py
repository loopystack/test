from django.urls import path, include
from rest_framework.routers import DefaultRouter, SimpleRouter
from . import views

# Create routers
router = DefaultRouter()
router.register(r'', views.ProjectViewSet, basename='project')
router.register(r'admin/projects', views.AdminProjectViewSet, basename='admin-project')

# Nested routers for project-specific resources
project_router = SimpleRouter()
project_router.register(r'versions', views.ProjectVersionViewSet, basename='project-version')
project_router.register(r'computing-resources', views.ComputingResourceViewSet, basename='computing-resource')

urlpatterns = [
    # Code execution endpoint
    path('execute-code/', views.CodeExecutionView.as_view(), name='execute-code'),
    
    # Public project endpoints
    path('public/<uuid:public_url>/', views.PublicProjectView.as_view(), name='public-project'),
    
    # Main project routes
    path('', include(router.urls)),
    
    # Nested routes for project-specific resources
    path('<uuid:project_pk>/', include(project_router.urls)),
] 