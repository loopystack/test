from rest_framework import serializers
from .models import Project, ProjectVersion, ProjectCollaborator, ProjectUsage, ComputingResource, ProjectPurchase, ProjectView
from django.contrib.auth import get_user_model
from django.db import models

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email', 'first_name', 'last_name', 'avatar']

class ComputingResourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = ComputingResource
        fields = '__all__'
        read_only_fields = ['project', 'estimated_cost_per_run', 'created_at', 'updated_at']

class ProjectCollaboratorSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    user_id = serializers.UUIDField(write_only=True)
    
    class Meta:
        model = ProjectCollaborator
        fields = ['id', 'user', 'user_id', 'role', 'is_public', 'added_at']
        read_only_fields = ['added_at']

class ProjectVersionSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    approved_by = UserSerializer(read_only=True)
    
    class Meta:
        model = ProjectVersion
        fields = '__all__'
        read_only_fields = ['id', 'project', 'created_by', 'approved_by', 'approved_at', 'created_at']

class ProjectUsageSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = ProjectUsage
        fields = '__all__'
        read_only_fields = ['user', 'total_cost', 'last_used']

class ProjectPurchaseSerializer(serializers.ModelSerializer):
    buyer = UserSerializer(read_only=True)
    
    class Meta:
        model = ProjectPurchase
        fields = '__all__'
        read_only_fields = ['buyer', 'purchased_at']

class ProjectViewSerializer(serializers.ModelSerializer):
    viewer = UserSerializer(read_only=True)
    
    class Meta:
        model = ProjectView
        fields = '__all__'
        read_only_fields = ['viewer', 'viewed_at']

class ProjectSerializer(serializers.ModelSerializer):
    owner = UserSerializer(read_only=True)
    collaborators = ProjectCollaboratorSerializer(source='projectcollaborator_set', many=True, read_only=True)
    computing_resources = ComputingResourceSerializer(many=True, read_only=True)
    latest_public_version = serializers.SerializerMethodField()
    latest_private_version = serializers.SerializerMethodField()
    usage_count = serializers.SerializerMethodField()
    content = serializers.SerializerMethodField()
    usage_instructions = serializers.SerializerMethodField()
    analytics = serializers.SerializerMethodField()
    
    class Meta:
        model = Project
        fields = [
            'id', 'title', 'description', 'owner', 'collaborators', 'computing_resources',
            'is_public', 'is_approved', 'project_type', 'language', 'status', 'price', 'price_per_use',
            'public_url', 'private_url', 'created_at', 'updated_at',
            'latest_public_version', 'latest_private_version', 'usage_count',
            'content', 'usage_instructions', 'analytics'
        ]
        read_only_fields = ['id', 'owner', 'public_url', 'private_url', 'created_at', 'updated_at']
    
    def get_latest_public_version(self, obj):
        latest = obj.versions.filter(version_type='public', is_approved=True).first()
        return ProjectVersionSerializer(latest).data if latest else None
    
    def get_latest_private_version(self, obj):
        latest = obj.versions.filter(version_type='private', is_approved=True).first()
        return ProjectVersionSerializer(latest).data if latest else None
    
    def get_usage_count(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            usage = obj.usage_records.filter(user=request.user).first()
            return usage.usage_count if usage else 0
        return 0
    
    def get_content(self, obj):
        latest_version = obj.versions.filter(version_type='private').first()
        return latest_version.content if latest_version else ''
    
    def get_usage_instructions(self, obj):
        latest_version = obj.versions.filter(version_type='private').first()
        return latest_version.usage_instructions if latest_version else ''
    
    def get_analytics(self, obj):
        return {
            'total_views': obj.total_views,
            'total_runs': obj.total_runs,
            'total_purchases': obj.total_purchases,
            'total_revenue': str(obj.total_revenue)
        }

class ProjectCreateSerializer(serializers.ModelSerializer):
    content = serializers.CharField(required=False, allow_blank=True)
    usage_instructions = serializers.CharField(required=False, allow_blank=True)
    examples = serializers.ListField(required=False, default=list)
    owner = UserSerializer(read_only=True)
    
    class Meta:
        model = Project
        fields = ['id', 'title', 'description', 'is_public', 'project_type', 'language', 'price', 'price_per_use', 'content', 'usage_instructions', 'examples', 'owner', 'created_at', 'updated_at']
        read_only_fields = ['id', 'owner', 'created_at', 'updated_at']
    
    def create(self, validated_data):
        # Extract fields that don't belong to Project model
        content = validated_data.pop('content', '')
        usage_instructions = validated_data.pop('usage_instructions', '')
        examples = validated_data.pop('examples', [])
        
        # Ensure owner is set to current user
        request = self.context.get('request')
        if request and hasattr(request, 'user'):
            validated_data['owner'] = request.user
        else:
            raise serializers.ValidationError("User context is required")
        
        # Create the project
        project = super().create(validated_data)
        
        # Create initial version with the content
        if content or usage_instructions:
            ProjectVersion.objects.create(
                project=project,
                version_number=1,
                version_type='private',
                content=content,
                usage_instructions=usage_instructions,
                examples=examples,
                created_by=request.user,
                is_approved=True
            )
        
        return project

class ProjectUpdateSerializer(serializers.ModelSerializer):
    content = serializers.CharField(required=False, allow_blank=True)
    usage_instructions = serializers.CharField(required=False, allow_blank=True)
    examples = serializers.ListField(required=False)
    owner = UserSerializer(read_only=True)
    
    class Meta:
        model = Project
        fields = ['id', 'title', 'description', 'is_public', 'project_type', 'language', 'price', 'price_per_use', 'status', 'content', 'usage_instructions', 'examples', 'owner', 'created_at', 'updated_at']
        read_only_fields = ['id', 'owner', 'created_at', 'updated_at']
    
    def update(self, instance, validated_data):
        # Extract fields that don't belong to Project model
        content = validated_data.pop('content', None)
        usage_instructions = validated_data.pop('usage_instructions', None)
        examples = validated_data.pop('examples', None)
        
        # Ensure owner is not changed
        if 'owner' in validated_data:
            validated_data.pop('owner')
        
        # Update the project
        project = super().update(instance, validated_data)
        
        # Update or create the latest private version with the content
        if content is not None or usage_instructions is not None or examples is not None:
            latest_version = project.versions.filter(version_type='private').first()
            
            if latest_version:
                # Update existing version
                if content is not None:
                    latest_version.content = content
                if usage_instructions is not None:
                    latest_version.usage_instructions = usage_instructions
                if examples is not None:
                    latest_version.examples = examples
                latest_version.save()
            else:
                # Create new version
                request = self.context.get('request')
                if request and hasattr(request, 'user'):
                    created_by = request.user
                else:
                    created_by = project.owner
                
                ProjectVersion.objects.create(
                    project=project,
                    version_number=1,
                    version_type='private',
                    content=content or '',
                    usage_instructions=usage_instructions or '',
                    examples=examples or [],
                    created_by=created_by,
                    is_approved=True
                )
        
        return project

class ProjectVersionCreateSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    
    class Meta:
        model = ProjectVersion
        fields = ['id', 'version_number', 'version_type', 'content', 'code_content', 'text_content', 'usage_instructions', 'examples', 'created_by', 'created_at']
        read_only_fields = ['id', 'created_by', 'created_at']
    
    def create(self, validated_data):
        validated_data['project_id'] = self.context['project_id']
        validated_data['created_by'] = self.context['request'].user
        return super().create(validated_data)

class ProjectSearchSerializer(serializers.ModelSerializer):
    owner = UserSerializer(read_only=True)
    latest_public_version = serializers.SerializerMethodField()
    analytics = serializers.SerializerMethodField()
    
    class Meta:
        model = Project
        fields = ['id', 'title', 'description', 'owner', 'is_public', 'project_type', 
                 'price', 'price_per_use', 'created_at', 'latest_public_version', 'analytics']
    
    def get_latest_public_version(self, obj):
        latest = obj.versions.filter(version_type='public', is_approved=True).first()
        return ProjectVersionSerializer(latest).data if latest else None
    
    def get_analytics(self, obj):
        return {
            'total_views': obj.total_views,
            'total_runs': obj.total_runs,
            'total_purchases': obj.total_purchases
        }

class ProjectRunSerializer(serializers.Serializer):
    project_id = serializers.UUIDField()
    input_data = serializers.JSONField(required=False)
    parameters = serializers.JSONField(required=False)

class ProjectBuySerializer(serializers.Serializer):
    project_id = serializers.UUIDField()
    purchase_type = serializers.ChoiceField(choices=[
        ('one_time', 'One-time Purchase'),
        ('per_use', 'Per-use Payment')
    ])
    payment_method = serializers.CharField(max_length=50, required=False)

class ProjectAnalyticsSerializer(serializers.ModelSerializer):
    owner = UserSerializer(read_only=True)
    recent_purchases = ProjectPurchaseSerializer(many=True, read_only=True)
    recent_views = ProjectViewSerializer(many=True, read_only=True)
    usage_stats = serializers.SerializerMethodField()
    
    class Meta:
        model = Project
        fields = ['id', 'title', 'owner', 'total_views', 'total_runs', 'total_purchases', 
                 'total_revenue', 'recent_purchases', 'recent_views', 'usage_stats']
    
    def get_usage_stats(self, obj):
        # Get usage statistics for the last 30 days
        from django.utils import timezone
        from datetime import timedelta
        
        thirty_days_ago = timezone.now() - timedelta(days=30)
        
        recent_views = obj.views.filter(viewed_at__gte=thirty_days_ago).count()
        recent_runs = obj.usage_records.filter(last_used__gte=thirty_days_ago).aggregate(
            total_runs=models.Sum('usage_count')
        )['total_runs'] or 0
        recent_purchases = obj.purchases.filter(purchased_at__gte=thirty_days_ago).count()
        
        return {
            'views_last_30_days': recent_views,
            'runs_last_30_days': recent_runs,
            'purchases_last_30_days': recent_purchases
        } 