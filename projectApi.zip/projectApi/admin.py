from django.contrib import admin
from .models import Project, ProjectVersion, ProjectCollaborator, ProjectUsage, ComputingResource

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'owner', 'is_public', 'is_approved', 'price', 'created_at')
    list_filter = ('is_public', 'is_approved', 'created_at', 'project_type')
    search_fields = ('title', 'description', 'owner__email')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(ProjectVersion)
class ProjectVersionAdmin(admin.ModelAdmin):
    list_display = ('project', 'version_number', 'is_approved', 'created_by', 'created_at')
    list_filter = ('is_approved', 'created_at')
    search_fields = ('project__title', 'content', 'created_by__email')

@admin.register(ProjectCollaborator)
class ProjectCollaboratorAdmin(admin.ModelAdmin):
    list_display = ('project', 'user', 'role')
    list_filter = ('role',)
    search_fields = ('project__title', 'user__email')

@admin.register(ProjectUsage)
class ProjectUsageAdmin(admin.ModelAdmin):
    list_display = ('project', 'user', 'usage_count', 'total_cost', 'last_used')
    list_filter = ('last_used',)
    search_fields = ('project__title', 'user__email')

@admin.register(ComputingResource)
class ComputingResourceAdmin(admin.ModelAdmin):
    list_display = ('project', 'cpu_usage', 'memory_usage', 'estimated_cost_per_run', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('project__title',) 