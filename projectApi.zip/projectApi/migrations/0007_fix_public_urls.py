# Generated manually to fix public URLs

from django.db import migrations

def fix_public_urls(apps, schema_editor):
    Project = apps.get_model('projectApi', 'Project')
    
    for project in Project.objects.all():
        # Update public_url to just the project ID
        project.public_url = str(project.id)
        project.private_url = str(project.id)
        project.save(update_fields=['public_url', 'private_url'])

def reverse_fix_public_urls(apps, schema_editor):
    Project = apps.get_model('projectApi', 'Project')
    
    for project in Project.objects.all():
        # Revert to old format if needed
        project.public_url = f"projects/{project.id}/public"
        project.private_url = f"projects/{project.id}/private"
        project.save(update_fields=['public_url', 'private_url'])

class Migration(migrations.Migration):

    dependencies = [
        ('projectApi', '0006_computingresource_complexity_score_and_more'),
    ]

    operations = [
        migrations.RunPython(fix_public_urls, reverse_fix_public_urls),
    ] 