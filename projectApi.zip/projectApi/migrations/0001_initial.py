# Generated manually for projectApi

from django.db import migrations, models
import django.db.models.deletion
import uuid


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('authApi', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Project',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('title', models.CharField(max_length=200)),
                ('description', models.TextField()),
                ('is_public', models.BooleanField(default=False)),
                ('is_approved', models.BooleanField(default=False)),
                ('project_type', models.CharField(choices=[('code', 'Code Project'), ('text', 'Text Project'), ('mixed', 'Mixed Content')], default='code', max_length=10)),
                ('status', models.CharField(choices=[('draft', 'Draft'), ('pending', 'Pending Review'), ('approved', 'Approved'), ('rejected', 'Rejected')], default='draft', max_length=20)),
                ('price', models.DecimalField(decimal_places=2, default=0.0, max_digits=10)),
                ('price_per_use', models.DecimalField(decimal_places=2, default=0.1, max_digits=10)),
                ('public_url', models.CharField(blank=True, max_length=255, null=True)),
                ('private_url', models.CharField(blank=True, max_length=255, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('owner', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='owned_projects', to='authApi.user')),
            ],
            options={
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='ProjectVersion',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('version_number', models.IntegerField()),
                ('version_type', models.CharField(choices=[('public', 'Public Version'), ('private', 'Private Version')], default='public', max_length=10)),
                ('content', models.TextField()),
                ('code_content', models.TextField(blank=True, null=True)),
                ('text_content', models.TextField(blank=True, null=True)),
                ('is_approved', models.BooleanField(default=False)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('approved_at', models.DateTimeField(blank=True, null=True)),
                ('approved_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='approved_versions', to='authApi.user')),
                ('created_by', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='authApi.user')),
                ('project', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='versions', to='projectApi.project')),
            ],
            options={
                'ordering': ['-version_number'],
                'unique_together': {('project', 'version_number', 'version_type')},
            },
        ),
        migrations.CreateModel(
            name='ProjectCollaborator',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('role', models.CharField(choices=[('viewer', 'Viewer'), ('editor', 'Editor'), ('admin', 'Admin')], default='viewer', max_length=10)),
                ('can_edit', models.BooleanField(default=False)),
                ('can_approve', models.BooleanField(default=False)),
                ('is_public', models.BooleanField(default=False)),
                ('added_at', models.DateTimeField(auto_now_add=True)),
                ('project', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='projectApi.project')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='authApi.user')),
            ],
            options={
                'unique_together': {('project', 'user')},
            },
        ),
        migrations.CreateModel(
            name='ProjectUsage',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('usage_count', models.IntegerField(default=0)),
                ('total_cost', models.DecimalField(decimal_places=2, default=0.0, max_digits=10)),
                ('last_used', models.DateTimeField(auto_now=True)),
                ('project', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='usage_records', to='projectApi.project')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='authApi.user')),
            ],
            options={
                'unique_together': {('project', 'user')},
            },
        ),
        migrations.CreateModel(
            name='ComputingResource',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('cpu_usage', models.FloatField(default=0.0)),
                ('memory_usage', models.FloatField(default=0.0)),
                ('execution_time', models.FloatField(default=0.0)),
                ('estimated_cost_per_run', models.DecimalField(decimal_places=4, default=0.0, max_digits=10)),
                ('monthly_server_cost', models.DecimalField(decimal_places=2, default=20.0, max_digits=10)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('project', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='computing_resources', to='projectApi.project')),
            ],
        ),
        migrations.AddField(
            model_name='project',
            name='collaborators',
            field=models.ManyToManyField(through='projectApi.ProjectCollaborator', to='authApi.user'),
        ),
    ] 