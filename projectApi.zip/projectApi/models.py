from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone
import uuid

User = get_user_model()

class Project(models.Model):
    PROJECT_TYPE_CHOICES = [
        ('code', 'Code Project'),
        ('text', 'Text Project'),
    ]
    
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('pending', 'Pending Review'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=200)
    description = models.TextField()
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='owned_projects')
    collaborators = models.ManyToManyField(User, through='ProjectCollaborator', related_name='collaborated_projects')
    
    # Project settings
    is_public = models.BooleanField(default=False)
    is_approved = models.BooleanField(default=False)
    project_type = models.CharField(max_length=10, choices=PROJECT_TYPE_CHOICES, default='code')
    language = models.CharField(max_length=20, blank=True, null=True, help_text='Programming language for code projects')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    
    # Pricing
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    price_per_use = models.DecimalField(max_digits=10, decimal_places=2, default=0.10)
    
    # URLs
    public_url = models.CharField(max_length=255, blank=True, null=True)
    private_url = models.CharField(max_length=255, blank=True, null=True)
    
    # Analytics
    total_views = models.IntegerField(default=0)
    total_runs = models.IntegerField(default=0)
    total_purchases = models.IntegerField(default=0)
    total_revenue = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        if not self.public_url:
            self.public_url = str(self.id)
        if not self.private_url:
            self.private_url = str(self.id)
        super().save(*args, **kwargs)
    
    def increment_view(self):
        self.total_views += 1
        self.save(update_fields=['total_views'])
    
    def increment_run(self):
        self.total_runs += 1
        self.save(update_fields=['total_runs'])
    
    def increment_purchase(self, amount):
        self.total_purchases += 1
        self.total_revenue += amount
        self.save(update_fields=['total_purchases', 'total_revenue'])

class ProjectVersion(models.Model):
    VERSION_TYPE_CHOICES = [
        ('public', 'Public Version'),
        ('private', 'Private Version'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='versions')
    version_number = models.IntegerField()
    version_type = models.CharField(max_length=10, choices=VERSION_TYPE_CHOICES, default='public')
    
    # Content
    content = models.TextField()
    code_content = models.TextField(blank=True, null=True)
    text_content = models.TextField(blank=True, null=True)
    usage_instructions = models.TextField(blank=True, null=True)
    examples = models.JSONField(default=list, blank=True, help_text='List of usage examples')
    
    # Metadata
    is_approved = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    approved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_versions')
    rejection_reason = models.TextField(blank=True, null=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        unique_together = ['project', 'version_number', 'version_type']
        ordering = ['-version_number']
    
    def __str__(self):
        return f"{self.project.title} - v{self.version_number} ({self.version_type})"
    
    def approve(self, approved_by_user):
        self.is_approved = True
        self.approved_by = approved_by_user
        self.approved_at = timezone.now()
        self.save()
    
    def reject(self, rejected_by_user, reason=''):
        self.is_approved = False
        self.approved_by = None
        self.rejection_reason = reason
        self.save()

class ProjectCollaborator(models.Model):
    ROLE_CHOICES = [
        ('editor', 'Editor'),
        ('admin', 'Admin'),
    ]
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='editor')
    is_public = models.BooleanField(default=False)  # Whether this collaborator is visible publicly
    
    # Timestamps
    added_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['project', 'user']
    
    def __str__(self):
        return f"{self.user.email} - {self.project.title} ({self.role})"

class ProjectUsage(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='usage_records')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    usage_count = models.IntegerField(default=0)
    total_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    last_used = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['project', 'user']
    
    def __str__(self):
        return f"{self.user.email} - {self.project.title} ({self.usage_count} uses)"
    
    def increment_usage(self, cost_per_use=None):
        self.usage_count += 1
        if cost_per_use:
            self.total_cost += cost_per_use
        else:
            self.total_cost += self.project.price_per_use
        self.save()

class ComputingResource(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='computing_resources')
    
    # Resource usage estimates
    cpu_usage = models.FloatField(default=0.0)  # CPU usage percentage
    memory_usage = models.FloatField(default=0.0)  # Memory usage in MB
    execution_time = models.FloatField(default=0.0)  # Estimated execution time in seconds
    storage_usage = models.FloatField(default=0.0)  # Storage usage in MB
    
    # Cost calculations
    estimated_cost_per_run = models.DecimalField(max_digits=10, decimal_places=4, default=0.0000)
    monthly_server_cost = models.DecimalField(max_digits=10, decimal_places=2, default=20.00)  # $20/month
    
    # Performance metrics
    complexity_score = models.IntegerField(default=0)  # Code complexity score (1-100)
    resource_intensity = models.CharField(max_length=20, default='low')  # low, medium, high
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.project.title} - Computing Resources"
    
    def calculate_cost_per_run(self):
        """Calculate cost per run based on resource usage"""
        # More accurate calculation based on actual resource consumption
        # CPU cost: percentage of CPU used * time * monthly cost
        cpu_cost = (self.cpu_usage / 100) * (self.execution_time / 3600) * (self.monthly_server_cost / (30 * 24))
        
        # Memory cost: memory usage in MB * time * monthly cost / total memory (assuming 8GB server)
        memory_cost = (self.memory_usage / 8192) * (self.execution_time / 3600) * (self.monthly_server_cost / (30 * 24))
        
        # Storage cost: storage usage in MB * monthly cost / total storage (assuming 100GB server)
        storage_cost = (self.storage_usage / 102400) * (self.monthly_server_cost / (30 * 24 * 3600))
        
        # Total cost per run
        total_cost = cpu_cost + memory_cost + storage_cost
        
        # Minimum cost to cover overhead
        min_cost = 0.001  # $0.001 minimum per run
        
        self.estimated_cost_per_run = max(total_cost, min_cost)
        return self.estimated_cost_per_run
    
    def analyze_complexity(self, code_content):
        """Analyze code complexity and set resource intensity"""
        if not code_content:
            return
        
        lines = len(code_content.split('\n'))
        imports = len([line for line in code_content.split('\n') if line.strip().startswith(('import', 'from', 'require', 'using'))])
        functions = code_content.count('function') + code_content.count('def ') + code_content.count('public ') + code_content.count('private ')
        loops = code_content.count('for ') + code_content.count('while ') + code_content.count('forEach')
        conditionals = code_content.count('if ') + code_content.count('else ') + code_content.count('switch ')
        
        # More sophisticated complexity calculation
        base_complexity = lines * 0.3
        import_complexity = imports * 3
        function_complexity = functions * 2
        loop_complexity = loops * 1.5
        conditional_complexity = conditionals * 1
        
        # Calculate complexity score (0-100)
        self.complexity_score = min(100, base_complexity + import_complexity + function_complexity + loop_complexity + conditional_complexity)
        
        # Set resource intensity based on complexity
        if self.complexity_score < 25:
            self.resource_intensity = 'low'
        elif self.complexity_score < 60:
            self.resource_intensity = 'medium'
        else:
            self.resource_intensity = 'high'
        
        # Update resource estimates based on complexity and language patterns
        # CPU usage: more complex code uses more CPU
        self.cpu_usage = min(100, max(5, self.complexity_score * 0.7))
        
        # Memory usage: based on complexity and imports
        base_memory = 50  # Base memory usage in MB
        memory_per_import = 10  # Additional memory per import
        memory_per_function = 5  # Additional memory per function
        self.memory_usage = min(1000, base_memory + (imports * memory_per_import) + (functions * memory_per_function))
        
        # Execution time: based on complexity and loops
        base_time = 0.5  # Base execution time in seconds
        time_per_loop = 0.2  # Additional time per loop
        time_per_function = 0.1  # Additional time per function
        self.execution_time = min(30, base_time + (loops * time_per_loop) + (functions * time_per_function))
        
        # Storage usage: based on code size and complexity
        self.storage_usage = min(100, max(1, lines * 0.1 + self.complexity_score * 0.3))
        
        # Calculate cost per run
        self.calculate_cost_per_run()
        self.save()

class ProjectPurchase(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='purchases')
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='project_purchases')
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2)
    purchase_type = models.CharField(max_length=20, choices=[
        ('one_time', 'One-time Purchase'),
        ('per_use', 'Per-use Payment')
    ])
    transaction_id = models.CharField(max_length=255, blank=True, null=True)
    
    # Timestamps
    purchased_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-purchased_at']
    
    def __str__(self):
        return f"{self.buyer.email} - {self.project.title} (${self.amount_paid})"

class ProjectView(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='views')
    viewer = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField(blank=True)
    
    # Timestamps
    viewed_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-viewed_at']
    
    def __str__(self):
        return f"{self.project.title} - {self.viewed_at}" 